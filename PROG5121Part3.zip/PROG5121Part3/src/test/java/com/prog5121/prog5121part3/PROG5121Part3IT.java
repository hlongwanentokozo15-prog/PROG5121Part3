/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.prog5121.prog5121part3;

import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author NTOKOZO
 */
public class PROG5121Part3IT {
    
    public PROG5121Part3IT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class PROG5121Part3.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        PROG5121Part3.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loadTestData method, of class PROG5121Part3.
     */
    @Test
    public void testLoadTestData() {
        System.out.println("loadTestData");
        PROG5121Part3.loadTestData();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of createMessageHash method, of class PROG5121Part3.
     */
    @Test
    public void testCreateMessageHash() {
        System.out.println("createMessageHash");
        String id = "";
        String msg = "";
        String expResult = "";
        String result = PROG5121Part3.createMessageHash(id, msg);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of storedMessagesMenu method, of class PROG5121Part3.
     */
    @Test
    public void testStoredMessagesMenu() {
        System.out.println("storedMessagesMenu");
        PROG5121Part3.storedMessagesMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displaySenderRecipient method, of class PROG5121Part3.
     */
    @Test
    public void testDisplaySenderRecipient() {
        System.out.println("displaySenderRecipient");
        PROG5121Part3.displaySenderRecipient();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayLongestMessage method, of class PROG5121Part3.
     */
    @Test
    public void testDisplayLongestMessage() {
        System.out.println("displayLongestMessage");
        PROG5121Part3.displayLongestMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByMessageID method, of class PROG5121Part3.
     */
    @Test
    public void testSearchByMessageID() {
        System.out.println("searchByMessageID");
        Scanner sc = null;
        PROG5121Part3.searchByMessageID(sc);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByRecipient method, of class PROG5121Part3.
     */
    @Test
    public void testSearchByRecipient() {
        System.out.println("searchByRecipient");
        Scanner sc = null;
        PROG5121Part3.searchByRecipient(sc);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteByHash method, of class PROG5121Part3.
     */
    @Test
    public void testDeleteByHash() {
        System.out.println("deleteByHash");
        Scanner sc = null;
        PROG5121Part3.deleteByHash(sc);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayReport method, of class PROG5121Part3.
     */
    @Test
    public void testDisplayReport() {
        System.out.println("displayReport");
        PROG5121Part3.displayReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
